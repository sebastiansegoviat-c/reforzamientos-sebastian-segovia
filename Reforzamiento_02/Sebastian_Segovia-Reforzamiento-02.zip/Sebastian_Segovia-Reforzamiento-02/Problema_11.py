#11. Identificar qué tipo de dato se obtiene al elevar tu edad con
#exponente 5 y luego dividirlo por 10. Mostrar el resultado de su módulo con
#3 en pantalla

mi_edad = 19
pow_edad = mi_edad ** 5
div_edad = pow_edad / 10
mod_edad = div_edad % 3
print("El resultado de la división es: {} y su módulo es: {}".format(f"{div_edad:.2f}", f"{mod_edad:.2f}"))