#8.Usando la condicional if imprimir por pantalla si una lista ([]) está vacía o no, comprobar con una lista vacía y otra con una lista con dato al menos ([dato_1, dato_2]).

lista1 = [3, 9, 27, 81]
lista2 = []

if lista1 == 0:
    print("La lista 1 esta vacía")
else:
    print("La lista 1 esta llena")
if not lista2 == 0:
    print("La lista 2 esta vacía")
else:
    print("La lista 2 esta llena")