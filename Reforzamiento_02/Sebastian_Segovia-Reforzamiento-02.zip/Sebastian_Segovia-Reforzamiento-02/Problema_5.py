#5.Crear un programa que inicia creando un sueldo en una variable, sepamos si es par o impar mediante un mensaje. Utilizar módulo y condicional (if).

sueldo = 4297
if sueldo % 2 == 0:
    print("El sueldo de {} es par".format(sueldo))
if sueldo % 2 :
    print("El sueldo de {} es impar".format(sueldo))