#2.Crea una variable tipo int. Luego, multiplica por 10 y restarle el valor de 10.
# Debes hacer todo esto en dos pasos
# Finalmente convertirlo a float y mostrar el resultado por pantalla y el tipo de variable también.

var1 = 15
var2 = var1 * 10
var3 = var2 - 10
varfloat = float(var3)
print(varfloat)
print("La clase es: {}".format(type(varfloat)))