#6. Calcular la media de 5 datos (floats), cada dato debe estar en una variable y la media también.
# Mostrar el resultado en pantalla y el tipo de dato también mostrarlo.

num1 = 13.56
num2 = 37.12
num3 = 6.78
num4 = 11.13
num5 = 9.98
media = (num1 + num2 + num3 + num4 + num5) / 5
print("La media es: {}".format(f"{media:.2f}"))
print("La clase de la media es: {}".format(type(media)))