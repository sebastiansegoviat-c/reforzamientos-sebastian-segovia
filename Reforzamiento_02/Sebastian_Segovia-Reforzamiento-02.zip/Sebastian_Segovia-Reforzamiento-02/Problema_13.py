#13. Crea un programa que convierta una temperatura en grados Celsius a
#Fahrenheit. La fórmula que tiene que tener en cuenta es la siguiente:
#F = (C * 9)/5 + 32
#Deberá imprimir algo como lo siguiente:
#La temperatura en °C: 30
#Temperatura en Fahrenheit: 86.00
#Realizarlo con dos distintos datos para la temperatura en Celsius (usar dos
#variables iniciales para obtener dos temperaturas finales en Fahrenheit)

celsius1 = 60
fahrenheit1 = (celsius1 * 9) / 5 + 32

celsius2 = 15
fahrenheit2 = (celsius2 * 9) / 5 + 32
print("La temperatura en °C: {}".format(celsius1))
print("La temperatura en Fahrenheit: {}".format(f"{fahrenheit1:.2f}"))

print("La temperatura en °C: {}".format(celsius2))
print("La temperatura en Fahrenheit: {}".format(f"{fahrenheit2:.2f}"))