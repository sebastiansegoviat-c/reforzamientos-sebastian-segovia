#4.Hallar el volumen de una esfera, cada dato requerido para hallar el volumen debe estar en una variable.
# Mostrar el volumen por pantalla indicándoselo al usuario.
# Considera a π = 3.14159
# La fórmula para calcular el volumen de una esfera es: V = (4/3). π . r ^3 Y finalmente deberá verse lo siguiente:

radio = 5.5
pi = 3.14159
volumen = (4/3) * pi * (radio ** 3)
print("Radio de la esfera: {}".format(radio))
print("Volumen de la esfera: {}".format(f"{volumen:.2f}"))