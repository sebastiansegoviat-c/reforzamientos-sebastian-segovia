#7.De 3 números asignados mayores a 30 (entre positivos y negativos tú los propones) a 3 variables, se pide hallar la suma de los valores de los módulos con 3, 5, y 7 respectivamente, mostrar en pantalla el valor de la suma.

num_1 = 77
num_2 = -109
num_3 = 59
modulo1 = num_1 % 3
modulo2 = num_2 % 5
modulo3 = num_3 % 7
suma_modulo = modulo1 + modulo2 + modulo3
print("El valor de la suma es: {}".format(suma_modulo))