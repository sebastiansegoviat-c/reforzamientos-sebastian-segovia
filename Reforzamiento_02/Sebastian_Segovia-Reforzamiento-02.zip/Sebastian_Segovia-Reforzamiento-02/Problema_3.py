#Crear una variable tipo string, luego súmala con otra variable tipo int, para esto convertir una de las variables para realizar este procedimiento sin errores.
# Mostrar la suma en pantalla.

varstr = "777"
varint = 23
suma = int(varstr) + varint
print(suma)