#Crear un programa que tome un número flotante en una
#variable con 6 decimales y se imprima de diferentes modos:
#- 1 decimal
#- 2 decimales
#- 4 decimales

flotante1 = 2.718281
print("El número con un decimal es: {}".format(f"{flotante1:.1f}"))
print("El número con un decimal es: {}".format(f"{flotante1:.2f}"))
print("El número con un decimal es: {}".format(f"{flotante1:.4f}"))