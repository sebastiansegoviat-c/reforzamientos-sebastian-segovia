#Escribe un programa que almacene información de un producto: Tu
#nombre, nombre del producto, precio unitario (float), cantidad (int) e
#imprimirá finalmente algo como lo siguiente:
#Buen día Nombre, el detalle de su compra es el siguiente:
#- Producto: Pollo a la brasa
#- Precio unitario: 50.50
#- Cantidad: 2
#- Total a pagar: 101

nombre_1 = "Sebastian"
producto = "acetona"
precio_unitario = 248.7
cantidad = "3 galones"
print("Buen día {}, el detalle de su compra es el siguiente:".format(nombre_1))
print("- Producto: {}".format(producto))
print("- Precio_unitario: {} soles".format(precio_unitario))
print("- Cantidad: {}".format(cantidad))