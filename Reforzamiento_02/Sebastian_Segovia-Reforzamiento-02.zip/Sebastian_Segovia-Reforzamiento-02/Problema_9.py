#9.Elevar una base al exponente de 6 (que estará dentro una variable), este número el cual su valor estará asignado a una variable y luego restar este mismo valor multiplicado por dos (usar pow o **). Mostrar el resultado final en pantalla.

base = 4
pow1 = base ** 6
resultado = pow1 - (2 * pow1)
print("El resultado es: {}".format(resultado))