#El valor de ‘¡HI TuNombre Apellido!’ imprimirlo en consola, el texto debe ser un string y deberás guardarlo en una variable llamada mi_saludo.
# Tu nombre completo debe estar en otra variable.

nombre = "Sebastian Segovia"
mi_saludo = "Hi {}".format(nombre)
print("Hi {}".format(nombre))
print("La clase es: {}".format(type("Hi {}".format(mi_saludo))))